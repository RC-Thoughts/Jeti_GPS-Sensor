/* 
  TinyGpsWrapper for Teensy 3.x
    -------------------------------------------------------------
    
    Copyright (C) 2015 Bernd Wokoeck
    
    Modified for RCT-Tools by Tero Salminen 2017
    - Converted to TinyGPS++
    - Converted for Arduino only
    - Added more values
    - Added user choises 
    
    Version history:
    1.00   02/21/2016  created
    1.01   05/01/2017  RCT version
    
    Dependencies:
    - TinyGPS
    - AltSoftSerial
  
**************************************************************/

#include "GpsSensor.h"

void GpsSensor::Init( enGpsSerial comPort )
{
  if( m_pSerial == 0 )
  m_pSerial = new AltSoftSerial;
  m_pSerial->begin(9600);
  delay(1000);
}

void GpsSensor::DoGpsSensor()
{
  if( m_pSerial )
  {
    while( m_pSerial->available() )
    {
      char c = m_pSerial->read();
      if( m_gps.encode( c ) )
      {
        m_flat = m_gps.location.lat();
        m_flon = m_gps.location.lng();
        m_age = m_gps.location.age();
        m_speedkm = (long)m_gps.speed.kmph();
        m_speedmi = (long)m_gps.speed.mph();
        m_altme   = m_gps.altitude.meters();
        m_altft  = m_gps.altitude.feet();
        m_coursedeg = m_gps.course.deg();
        m_hdop  = m_gps.hdop.value();
        m_valid = m_gps.location.isValid();
        m_sats = m_gps.satellites.value();
        break;
      }
    }
  }
}

